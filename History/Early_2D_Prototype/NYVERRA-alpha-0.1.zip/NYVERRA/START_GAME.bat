@echo off
cd /d "%~dp0"
py -3 client\client.py
if errorlevel 1 python client\client.py
pause
