import tkinter as tk
import socket,threading,json,queue,math,sys
W,H=1120,730
BG='#101b22'; FG='#d7e5e4'
class Game:
 def __init__(self,root):
  self.root=root;root.title('NYVERRA | Echo Frontier - Prototype 0.1');root.geometry(f'{W}x{H}');root.minsize(800,560)
  self.canvas=tk.Canvas(root,bg=BG,highlightthickness=0);self.canvas.pack(fill='both',expand=True)
  self.keys=set();self.q=queue.Queue();self.state=None;self.pid=None;self.connected=False;self.sock=None;self.choice='wall';self.lastinput=None
  root.bind('<KeyPress>',self.keydown);root.bind('<KeyRelease>',self.keyup);self.canvas.bind('<Button-1>',self.click)
  self.screen='connect';self.draw();root.after(40,self.update)
 def keydown(self,e):
  key=e.keysym.lower();self.keys.add(key)
  if key=='1':self.choice='wall'
  if key=='2':self.choice='campfire'
  if key=='3':self.choice='beacon'
  if key=='escape' and self.screen=='game':self.screen='menu'
  elif key=='escape' and self.screen=='menu':self.screen='game'
 def keyup(self,e):self.keys.discard(e.keysym.lower())
 def send(self,msg):
  if self.connected:
   try:self.sock.sendall((json.dumps(msg)+'\n').encode())
   except OSError:self.connected=False
 def connect(self):
  host=self.host.get().strip() or '127.0.0.1';name=self.name.get().strip() or 'Survivor'
  try:s=socket.create_connection((host,27840),timeout=3);s.settimeout(None)
  except OSError as e:self.status.config(text='Нет соединения: '+str(e));return
  self.sock=s;self.connected=True;self.screen='game';self.send({'type':'name','value':name})
  threading.Thread(target=self.recv,daemon=True).start()
  if hasattr(self,'panel'):self.panel.destroy()
 def recv(self):
  buf=b''
  try:
   while True:
    data=self.sock.recv(65536)
    if not data:break
    buf+=data
    while b'\n' in buf:
     line,buf=buf.split(b'\n',1)
     try:self.q.put(json.loads(line))
     except ValueError:pass
  except OSError:pass
  self.connected=False
 def update(self):
  while not self.q.empty():
   msg=self.q.get()
   if msg.get('type')=='welcome':self.pid=str(msg['id'])
   elif msg.get('type')=='state':self.state=msg
  if self.screen=='game' and self.connected:
   dx=int('d' in self.keys or 'right' in self.keys)-int('a' in self.keys or 'left' in self.keys)
   dy=int('s' in self.keys or 'down' in self.keys)-int('w' in self.keys or 'up' in self.keys)
   now=(dx,dy)
   if now!=self.lastinput:self.send({'type':'move','dx':dx,'dy':dy});self.lastinput=now
  self.draw();self.root.after(45,self.update)
 def camera(self):
  p=(self.state or {}).get('players',{}).get(self.pid,{'x':1200,'y':1200})
  return p['x'],p['y']
 def click(self,e):
  if self.screen!='game' or not self.state or not self.pid:return
  w,h=self.canvas.winfo_width(),self.canvas.winfo_height();cx,cy=self.camera()
  x=e.x-w/2+cx;y=e.y-h/2+cy
  if 'shift_l' in self.keys or 'shift_r' in self.keys:
   self.send({'type':'build','kind':self.choice,'x':int(x),'y':int(y)});return
  best=None;distance=42
  for i,n in self.state['nodes'].items():
   d=math.hypot(x-n['x'],y-n['y'])
   if n['hp']>0 and d<distance:best=i;distance=d
  if best is not None:self.send({'type':'harvest','id':best})
 def draw(self):
  c=self.canvas;c.delete('all');w=max(1,c.winfo_width());h=max(1,c.winfo_height())
  if self.screen=='connect':
   c.create_text(w/2,h*.21,text='N Y V E R R A',font=('Segoe UI',42,'bold'),fill='#8fe4d1')
   c.create_text(w/2,h*.3,text='ECHO FRONTIER  •  Multiplayer Survival',font=('Segoe UI',14),fill=FG)
   if not hasattr(self,'panel'):
    self.panel=tk.Frame(self.root,bg='#152730',padx=24,pady=20)
    tk.Label(self.panel,text='Сервер (IP)',bg='#152730',fg=FG).pack(anchor='w')
    self.host=tk.Entry(self.panel,width=30);self.host.insert(0,'127.0.0.1');self.host.pack(pady=5)
    tk.Label(self.panel,text='Имя игрока',bg='#152730',fg=FG).pack(anchor='w')
    self.name=tk.Entry(self.panel,width=30);self.name.insert(0,'Explorer');self.name.pack(pady=5)
    tk.Button(self.panel,text='ВОЙТИ В МИР',command=self.connect,bg='#52c7b0',activebackground='#81e8d6',padx=20,pady=8).pack(pady=12)
    self.status=tk.Label(self.panel,text='Сначала запустите сервер',fg='#ffbd7e',bg='#152730');self.status.pack()
    self.panel.place(relx=.5,rely=.61,anchor='center')
   return
  if not self.connected:
   c.create_text(w/2,h/2,text='Соединение потеряно. Перезапустите клиент.',fill='#ffc497',font=('Segoe UI',18));return
  if not self.state or not self.pid:return
  cx,cy=self.camera();ox=w/2-cx;oy=h/2-cy;phase=self.state['phase']
  c.configure(bg='#172d32' if phase==0 else '#28243b')
  for x in range(0,2401,100):
   sx=x+ox
   if 0<sx<w:c.create_line(sx,0,sx,h,fill='#345058' if phase==0 else '#493c57')
  for y in range(0,2401,100):
   sy=y+oy
   if 0<sy<h:c.create_line(0,sy,w,sy,fill='#345058' if phase==0 else '#493c57')
  c.create_rectangle(ox,oy,ox+2400,oy+2400,outline='#68beb3',width=4)
  for n in self.state['nodes'].values():
   if n['hp']<=0:continue
   x=n['x']+ox;y=n['y']+oy
   if not (-50<x<w+50 and -50<y<h+50):continue
   kind=n['kind'];color={'tree':'#3d9d78','rock':'#9aa7af','crystal':'#b28cff'}[kind]
   if kind=='tree':
    c.create_oval(x-17,y-13,x+17,y+18,fill=color,outline='#b0e3b4',width=2)
    c.create_line(x,y+13,x,y+22,fill='#ad8264',width=5)
   elif kind=='rock':c.create_polygon(x-18,y+8,x-12,y-12,x+9,y-17,x+19,y+7,x+5,y+17,fill=color,outline='#d0dbe1')
   else:c.create_polygon(x,y-22,x+13,y,x,y+20,x-13,y,fill=color,outline='#e6caff',width=2)
  for b in self.state['buildings'].values():
   x=b['x']+ox;y=b['y']+oy
   kind=b['kind'];color={'wall':'#aa8565','campfire':'#ff9d55','beacon':'#95f0eb'}[kind]
   c.create_rectangle(x-23,y-23,x+23,y+23,fill=color,outline='#f1f0df',width=2)
   c.create_text(x,y,text={'wall':'▥','campfire':'♨','beacon':'✦'}[kind],fill='#17252d',font=('Segoe UI',20,'bold'))
  for pid,p in self.state['players'].items():
   x=p['x']+ox;y=p['y']+oy
   c.create_oval(x-13,y-13,x+13,y+13,fill='#f8d992' if pid==self.pid else '#db8d97',outline='white',width=2)
   c.create_text(x,y-24,text=p['name'],fill=FG,font=('Segoe UI',10,'bold'))
  me=self.state['players'].get(self.pid)
  inv=me['inv'] if me else {'wood':0,'stone':0,'crystal':0}
  c.create_rectangle(12,12,min(w-10,560),105,fill='#101b22',outline='#447477')
  c.create_text(27,29,text='NYVERRA  |  '+('ТИХАЯ ФАЗА' if phase==0 else 'ЭХО-ФАЗА'),fill='#8fe4d1',anchor='w',font=('Segoe UI',14,'bold'))
  c.create_text(27,57,text=f'Древесина: {inv["wood"]}     Камень: {inv["stone"]}     Кристаллы: {inv["crystal"]}',fill=FG,anchor='w',font=('Segoe UI',11))
  c.create_text(27,82,text=f'Смена фазы через {self.state["remaining"]} сек.     Игроков: {len(self.state["players"])}',fill='#c1d1da',anchor='w')
  c.create_rectangle(12,h-87,min(w-12,880),h-12,fill='#101b22',outline='#447477')
  c.create_text(25,h-67,text='WASD / стрелки — движение  •  ЛКМ по ресурсам — добыча  •  Shift + ЛКМ — строительство',fill=FG,anchor='w',font=('Segoe UI',10))
  c.create_text(25,h-39,text=f'1: Стена (4 дерева)   2: Костёр (3 дерева, 2 камня)   3: Маяк (8 дерева, 6 камня, 3 кристалла)  |  Выбрано: {self.choice}',fill='#8fe4d1',anchor='w',font=('Segoe UI',10))
def main():
 root=tk.Tk();Game(root);root.mainloop()
if __name__=='__main__':main()
