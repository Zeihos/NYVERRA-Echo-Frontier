import socket, threading, json, time, random, math, pathlib, argparse
HOST='0.0.0.0'; PORT=27840
TICK=0.075
random.seed(211)
WORLD=2400
nodes={}
for i in range(145):
 x=random.randrange(90,WORLD-90); y=random.randrange(90,WORLD-90)
 kind=random.choices(['tree','rock','crystal'],[.57,.31,.12])[0]
 nodes[str(i)]={'x':x,'y':y,'kind':kind,'hp':3 if kind=='tree' else 4,'max_hp':3 if kind=='tree' else 4}
players={}; buildings={}; connections={}; lock=threading.RLock(); elapsed=0.; next_build=0
RECIPES={'wall':{'wood':4},'campfire':{'wood':3,'stone':2},'beacon':{'wood':8,'stone':6,'crystal':3}}
def send(c,obj):
 try:c.sendall((json.dumps(obj,separators=(',',':'))+'\n').encode())
 except OSError:pass
def dist(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
def action(pid,msg):
 global next_build
 with lock:
  p=players.get(pid)
  if not p:return
  typ=msg.get('type')
  if typ=='move':
   dx=max(-1,min(1,float(msg.get('dx',0))));dy=max(-1,min(1,float(msg.get('dy',0))))
   m=math.hypot(dx,dy) or 1
   p['input']=[dx/m,dy/m]
  elif typ=='harvest':
   n=nodes.get(str(msg.get('id','')))
   if n and n['hp']>0 and dist(p,n)<92 and time.monotonic()-p['last_hit']>.27:
    p['last_hit']=time.monotonic();n['hp']-=1
    if n['hp']==0:
     k={'tree':'wood','rock':'stone','crystal':'crystal'}[n['kind']]
     p['inv'][k]+=3 if k!='crystal' else 2
     n['respawn']=time.monotonic()+35
  elif typ=='build':
   kind=str(msg.get('kind',''))
   if kind not in RECIPES:return
   try:x=int(msg['x']);y=int(msg['y'])
   except (KeyError,ValueError,TypeError):return
   b={'x':x,'y':y}
   if not (30<x<WORLD-30 and 30<y<WORLD-30 and dist(p,b)<155):return
   if any(dist(b,v)<55 for v in buildings.values()):return
   recipe=RECIPES[kind]
   if any(p['inv'][k]<v for k,v in recipe.items()):return
   for k,v in recipe.items():p['inv'][k]-=v
   next_build+=1;buildings[str(next_build)]={'x':x,'y':y,'kind':kind,'owner':pid}
  elif typ=='name':
   name=''.join(c for c in str(msg.get('value','')) if c.isalnum() or c in ' _-')[:18].strip()
   if name:p['name']=name

def client_thread(sock,addr,pid):
 try:
  sock.settimeout(1.0)
  with lock:
   players[pid]={'x':1200+random.randint(-60,60),'y':1200+random.randint(-60,60),'name':'Survivor'+str(pid),'inv':{'wood':0,'stone':0,'crystal':0},'input':[0,0],'last_hit':0}
   connections[pid]=sock
  send(sock,{'type':'welcome','id':pid,'world':WORLD})
  buf=b''
  while True:
   try:chunk=sock.recv(8192)
   except socket.timeout:continue
   if not chunk:break
   buf+=chunk
   if len(buf)>65536:break
   while b'\n' in buf:
    line,buf=buf.split(b'\n',1)
    try:msg=json.loads(line)
    except (ValueError,UnicodeDecodeError):continue
    if isinstance(msg,dict):
     try:action(pid,msg)
     except (TypeError,ValueError,OverflowError):pass
 finally:
  with lock:players.pop(pid,None);connections.pop(pid,None)
  sock.close()

def tick_loop():
 global elapsed
 last=time.monotonic()
 while True:
  now=time.monotonic();dt=min(.15,now-last);last=now;elapsed+=dt
  with lock:
   for p in players.values():
    p['x']=max(20,min(WORLD-20,p['x']+p['input'][0]*210*dt))
    p['y']=max(20,min(WORLD-20,p['y']+p['input'][1]*210*dt))
   for n in nodes.values():
    if n['hp']==0 and now>=n.get('respawn',float('inf')):n['hp']=n['max_hp']
   phase=int(elapsed//75)%2
   state={'type':'state','phase':phase,'remaining':round(75-elapsed%75),
          'players':{str(k):{key:p[key] for key in ('x','y','name','inv')} for k,p in players.items()},
          'nodes':{k:{key:n[key] for key in ('x','y','kind','hp')} for k,n in nodes.items()},'buildings':buildings}
   data=(json.dumps(state,separators=(',',':'))+'\n').encode()
   peers=list(connections.items())
  for pid,s in peers:
   try:s.sendall(data)
   except OSError:pass
  time.sleep(TICK)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=PORT);args=parser.parse_args()
 with socket.socket() as srv:
  srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);srv.bind((HOST,args.port));srv.listen(50)
  print(f'NYVERRA dedicated server listening on 0.0.0.0:{args.port}',flush=True)
  threading.Thread(target=tick_loop,daemon=True).start()
  pid=0
  while True:
   sock,addr=srv.accept();pid+=1
   threading.Thread(target=client_thread,args=(sock,addr,pid),daemon=True).start()
if __name__=='__main__':main()
