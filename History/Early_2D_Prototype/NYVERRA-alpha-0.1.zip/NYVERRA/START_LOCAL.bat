@echo off
cd /d "%~dp0"
start "NYVERRA SERVER" cmd /k "py -3 server\server.py"
timeout /t 2 /nobreak >nul
py -3 client\client.py
if errorlevel 1 python client\client.py
